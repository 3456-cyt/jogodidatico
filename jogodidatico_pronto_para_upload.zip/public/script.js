function iniciarJogo() {
  alert('O jogo será iniciado!');
}
